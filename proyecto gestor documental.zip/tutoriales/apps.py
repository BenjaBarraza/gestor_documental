from django.apps import AppConfig


class TutorialesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tutoriales'
